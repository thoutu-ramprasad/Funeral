<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'social');
define('TIMEZONE', 'Asia/Kolkata');
define('ENCRYPTION_KEY', 'e8dc978538014164a639985ef4bfe03d');