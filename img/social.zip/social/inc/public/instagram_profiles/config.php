<?php
return [
    'id' => 'instagram_profiles',
    'name' => 'Instagram profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-instagram',
    'color' => '#d62976',
    'js' => [
    	'assets/js/instagram_profiles.js'
    ]
];