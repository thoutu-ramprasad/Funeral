<?php
return [
    'id' => 'linkedin_profiles',
    'name' => 'Linkedin profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-linkedin',
    'color' => '#0d77b7'
];