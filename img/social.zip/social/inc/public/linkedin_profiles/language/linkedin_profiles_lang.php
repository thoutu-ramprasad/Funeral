<?php
$lang["Linkedin profiles"] = "Linkedin profiles";
$lang["Linkedin profile"] = "Linkedin profile";
$lang["Success"] = "Success";
$lang["Please select a profile to ad"] = "Please select a profile to ad";
$lang["No profile to add"] = "No profile to add";
$lang["Add Linkedin profile"] = "Add Linkedin profile";
$lang["Linkedin"] = "Linkedin";
$lang["Linkedin API Configuration"] = "Linkedin API Configuration";
$lang["Add profile"] = "Add profile";
$lang["Choose the profile you'd like to manag"] = "Choose the profile you'd like to manag";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Linkedin"] = "Re-connect with Linkedin";
$lang["Callback URL:"] = "Callback URL:";
$lang["Click this link to create Linkedin app:"] = "Click this link to create Linkedin app:";
$lang["Linkedin api id"] = "Linkedin api id";
$lang["Linkedin api secret"] = "Linkedin api secret";