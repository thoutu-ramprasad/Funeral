<div class="preview-google_business">
    <div class="card">
        <div class="card-block p-0">

            <div class="preview-google_business-media item-post-type" data-type="photo">
                <div class="preview-content">
                    <div class="preview-media"></div>
                    
                    <div class="caption">
                        <div class="line-no-text"></div>
                        <div class="line-no-text"></div>
                        <div class="line-no-text w50"></div>
                    </div>
                </div>
            </div>

            <div class="preview-google_business-media item-post-type" data-type="media">
                <div class="preview-content">
                    <div class="preview-media"></div>
                    
                    <div class="caption">
                        <div class="line-no-text"></div>
                        <div class="line-no-text"></div>
                        <div class="line-no-text w50"></div>
                    </div>
                </div>
            </div>

            <div class="preview-google_business-link item-post-type" data-type="link">
                <div class="preview-content">
                    <div class="preview-media"></div>

                    <div class="caption">
                        <div class="line-no-text"></div>
                        <div class="line-no-text"></div>
                        <div class="line-no-text w50"></div>
                    </div>
                </div>
            </div>

            <div class="preview-google_business-text item-post-type" data-type="text">
                <div class="preview-content">
                    <div class="caption">
                        <div class="line-no-text"></div>
                        <div class="line-no-text"></div>
                        <div class="line-no-text w50"></div>
                    </div>
                </div>
            </div>

            <div class="preview-pinterest-media item-post-type" data-type="video">
                <div class="text-center p-25">
                    <?php _e("This social network not support post this post type")?>
                </div>
            </div>

        </div>
    </div>
</div>
