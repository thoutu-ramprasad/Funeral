<?php
return [
    'id' => 'google_my_business_profiles',
    'name' => 'Google my business profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fas fa-store',
    'color' => '#4b88ef'
];