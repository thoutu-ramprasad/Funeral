<?php
$lang["Google my business profiles"] = "Google my business profiles";
$lang["Google my business profile"] = "Google my business profile";
$lang["Success"] = "Success";
$lang["No profile to add"] = "No profile to add";
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["Add Google My Business profile"] = "Add Google My Business profile";
$lang["Google My Business"] = "Google My Business";
$lang["Add profile"] = "Add profile";
$lang["Choose the profile you'd like to manage"] = "Choose the profile you'd like to manage";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Google My Business"] = "Re-connect with Google My Business";
$lang["Callback URL:"] = "Callback URL:";
$lang["Click this link to create Google app:"] = "Click this link to create Google app:";
$lang["Google Client ID"] = "Google Client ID";
$lang["Google Client Secret"] = "Google Client Secret";
$lang["Google API Key"] = "Google API Key";