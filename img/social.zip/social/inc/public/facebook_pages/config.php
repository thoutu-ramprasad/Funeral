<?php
return [
    'id' => 'facebook_pages',
    'name' => 'Facebook pages',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-facebook-square',
    'color' => '#3b5998'
];