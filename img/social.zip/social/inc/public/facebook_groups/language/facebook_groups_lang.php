<?php
$lang["Success"] = "Success";
$lang["Facebook groups"] = "Facebook groups";
$lang["Facebook group"] = "Facebook group";
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["No profile to add"] = "No profile to add";
$lang["Facebook"] = "Facebook";
$lang["Add Facebook group"] = "Add Facebook group";
$lang["Add profile"] = "Add profile";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Facebook"] = "Re-connect with Facebook";
$lang["Choose the profile you'd like to manage"] = "Choose the profile you'd like to manage";
$lang["Permissions"] = "Permissions";
$lang["Callback URL:"] = "Callback URL:";