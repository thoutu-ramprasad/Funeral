<?php
$lang["Linkedin pages"] = "Linkedin pages";
$lang["Linkedin page"] = "Linkedin page";
$lang["Success"] = "Success";
$lang["No profile to add"] = "No profile to add";
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["Add Linkedin page"] = "Add Linkedin page";
$lang["Linkedin"] = "Linkedin";
$lang["Add profile"] = "Add profile";
$lang["Choose the profile you'd like to manage"] = "Choose the profile you'd like to manage";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Linkedin"] = "Re-connect with Linkedin";
$lang["Callback URL:"] = "Callback URL:";
$lang["Note: "] = "Note:";
$lang["To can add Linkedin pages you need register Marketing Developer Platform of Linkedin"] = "To can add Linkedin pages you need register Marketing Developer Platform of Linkedin";