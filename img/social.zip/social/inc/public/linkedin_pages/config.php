<?php
return [
    'id' => 'linkedin_pages',
    'name' => 'Linkedin pages',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-linkedin',
    'color' => '#0d77b7'
];