<?php
return [
    'id' => 'twitter_profiles',
    'name' => 'Twitter profiles',
    'author' => 'Stackcode',
    'author_uri' => 'https://stackposts.com',
    'version' => '1.0',
    'desc' => '',
    'icon' => 'fab fa-twitter',
    'color' => '#00acee'
];