<?php
$lang["Twitter profiles"] = "Twitter profiles";
$lang["Twitter profile"] = "Twitter profile";
$lang["Add Twitter profile"] = "Add Twitter profile";
$lang["Success"] = "Success";
$lang["Please select a profile to add"] = "Please select a profile to add";
$lang["No profile to add"] = "No profile to add";
$lang["Twitter"] = "Twitter";
$lang["Twitter API Configuration"] = "Twitter API Configuration";
$lang["Add profile"] = "Add profile";
$lang["Search"] = "Search";
$lang["If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile."] = "If you don't see your profiles above, you might try to reconnec, re-accept all permissions, and ensure that you're logged in to the correct profile.";
$lang["Re-connect with Twitter"] = "Re-connect with Twitter";
$lang["Callback URL:"] = "Callback URL:";
$lang["Click this link to create twitter app:"] = "Click this link to create twitter app:";
$lang["Twitter consumer id"] = "Twitter consumer id";
$lang["Twitter consumer secret"] = "Twitter consumer secret";